﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;


namespace ExerciseApp
{
    public partial class index : System.Web.UI.Page
    {

        MySql.Data.MySqlClient.MySqlConnection conn;
        MySql.Data.MySqlClient.MySqlCommand cmd;
        String queryStr;

        MySqlConnection conn2 = new MySqlConnection(@"server=localhost;User Id=root;Persist Security Info=True;database=exercisedb");


        protected void Page_Load(object sender, EventArgs e)
        {

        }
       

        protected void submit_Click(object sender, EventArgs e)
        {
                registerUser();   // is to link with function below
        
        }

        private void registerUser()
        {
            String ConnString = System.Configuration.ConfigurationManager.ConnectionStrings["ExerciseAppConnString"].ToString();

            conn = new MySql.Data.MySqlClient.MySqlConnection(ConnString);

            conn.Open();

            queryStr = "";

            queryStr = "INSERT INTO employees(emp_name,emp_email,emp_username,emp_password)" +
                "VALUES('" + fname.Text + "','" + email.Text + "','" + uname.Text + "','" + pass.Text + "')";


            cmd = new MySql.Data.MySqlClient.MySqlCommand(queryStr, conn);



            cmd.ExecuteReader();
            conn.Close();

            //Response.Write("Your Data has been saved successfully !");
            ms.Text = "Your Data has been saved successfully !";

            clr();


        }

        protected void update_Click(object sender, EventArgs e)
        {
            updated();
        }
        //Update code for easy coding
        private void updated()
        {
            conn2.Open();
            MySqlCommand cmd2 = conn2.CreateCommand();
            cmd2.CommandType = CommandType.Text;

            // cmd2.CommandText = "update userregistration2 set MiddleName='" + middlenameTextBox.Text + "' where FirstName='" + firstnameTextbox.Text + "'";

            cmd2.CommandText = "update employees set emp_email='" + email.Text + "',emp_username='" + uname.Text + "',emp_password='" + pass.Text + "' where emp_name='" + fname.Text + "'";

            cmd2.ExecuteNonQuery();
            conn2.Close();

            ms.Text ="Your Data has been Updated Successfully !";

            clr();

        }

        protected void delete_Click(object sender, EventArgs e)
        {
            deleted();
        }
        // this is the code for delete button

        private void deleted()
        {
            conn2.Open();
            MySqlCommand cmd2 = conn2.CreateCommand();
            cmd2.CommandType = CommandType.Text;

            cmd2.CommandText = "delete from employees where emp_name='" + fname.Text + "'";

            cmd2.ExecuteNonQuery();
            conn2.Close();

            //  Response.Write("Your Data has been Delete Permanently !");


            ms.Text = "Your Data has been deleted successfully !";

            clr();
        }

        protected void clear_Click(object sender, EventArgs e)
        {
            clr();
        }
        private void clr()
        {
            fname.Text = "";
            email.Text = "";
            pass.Text = "";
            uname.Text = "";
           // ms.Text = "Your entry fields have been cleared successfully !";

        }


    }
}